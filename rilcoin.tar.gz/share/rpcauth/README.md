RPC Tools
---------------------

### [RPCAuth](/share/rpcauth) ###

Create login credentials for a JSON-RPC user.

Usage:

    ./rpcauth.py <username>
